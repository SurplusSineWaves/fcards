This package allows you to create, edit and practice flashcards through a curses CLI.    
   
Usage: just type "fcards" - if that doesn't work, try "python -m fcards.fcards"    
    
If the program crashes, try making your terminal bigger / font smaller    
